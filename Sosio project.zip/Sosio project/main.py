from flask import Flask, render_template
import sqlite3

app = Flask(__name__)
@app.route('/')
def home():
    
    name = "Avanish"

    return render_template('index.html', name_template = name)

@app.route('/monthlybill')
def monthlybill():

    return render_template('monthlybill.html')

@app.route('/splitbill')
def splitbill():

    return render_template('splitbill.html')

app.run(debug=True)